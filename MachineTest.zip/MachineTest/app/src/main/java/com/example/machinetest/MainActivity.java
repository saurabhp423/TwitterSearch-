package com.example.machinetest;
import androidx.appcompat.app.AppCompatActivity;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URLEncoder;

import android.os.AsyncTask;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.json.JSONArray;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
    private TextView tweetDisplay;
    Button b1 ;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        tweetDisplay = (TextView) findViewById(R.id.tweet_txt);
        Button b1=(Button)findViewById(R.id.search_btn) ;
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                EditText searchTxt = (EditText) findViewById(R.id.search_edit);
                String searchTerm = searchTxt.getText().toString();
                if (searchTerm.length() > 0) {
                    try {
                        String encodedSearch = URLEncoder.encode(searchTerm, "UTF-8");
                        String searchURL = "https://api.twitter.com/1.1/search/tweets.json";
                        new GetTweets().execute(searchURL);
                    } catch (Exception e) {
                        tweetDisplay.setText("something went wrong");
                        e.printStackTrace();
                    }
                } else
                    tweetDisplay.setText("Enter a search query");
            }
        });
    }
    private class GetTweets extends AsyncTask<String, Void, String> {
        protected String doInBackground(String... twitterURL) {
            StringBuilder tweetFeedBuilder = new StringBuilder();
            for (String searchURL : twitterURL) {
                HttpClient tweetClient = new DefaultHttpClient();
                try {
                    HttpGet tweetGet = new HttpGet(searchURL);
                    HttpResponse tweetResponse = tweetClient.execute(tweetGet);
                    StatusLine searchStatus = tweetResponse.getStatusLine();
                    if (searchStatus.getStatusCode() == 200) {
                        HttpEntity tweetEntity = tweetResponse.getEntity();
                        InputStream tweetContent = tweetEntity.getContent();
                        InputStreamReader tweetInput = new InputStreamReader(tweetContent);
                        BufferedReader tweetReader = new BufferedReader(tweetInput);
                        String lineIn;
                        while ((lineIn = tweetReader.readLine()) != null) {
                            tweetFeedBuilder.append(lineIn);
                        }
                    } else
                        tweetDisplay.setText("something went wrong");
                } catch (Exception e) {
                    tweetDisplay.setText("something went wrong");
                    e.printStackTrace();
                }
            }
            return tweetFeedBuilder.toString();
        }

        protected void onPostExecute(String result) {
            StringBuilder tweetResultBuilder = new StringBuilder();
            try {
                JSONObject resultObject = new JSONObject(result);
                JSONArray tweetArray = resultObject.getJSONArray("results");
                for (int t = 0; t < tweetArray.length(); t++) {
                    JSONObject tweetObject = tweetArray.getJSONObject(t);
                    tweetResultBuilder.append(tweetObject.getString("from_user") + ": ");
                    tweetResultBuilder.append(tweetObject.get("text") + "\n\n");
                }
            } catch (Exception e) {
                tweetDisplay.setText("some" +
                        "thing went wrong");
                e.printStackTrace();
            }
            if (tweetResultBuilder.length() > 0)
                tweetDisplay.setText(tweetResultBuilder.toString());
            else
                tweetDisplay.setText("Sorry - no tweets found for your search!");
        }
    }
}